package bankmanagementsystem;

import java.awt.Color;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.Timer;

public class Login1 extends JFrame implements ActionListener  {
	
	Random rand=new Random();
	int first=rand.nextInt(10000);
	
	//Timer t;
	
	JPasswordField textField;
	   JButton b1,b2,b3;
	   String pin;
	Login1(){
		
		    ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/atm2.png"));
	        Image i2 = i1.getImage().getScaledInstance(1550,830,Image.SCALE_DEFAULT);
	        ImageIcon i3 = new ImageIcon(i2);
	        JLabel l3 = new JLabel(i3);
	        l3.setBounds(0,0,1550,830);
	        add(l3);
	        
	        JLabel label1 = new JLabel("ENTER YOUR PIN");
	        label1.setForeground(Color.WHITE);
	        label1.setFont(new Font("System", Font.BOLD, 16));
	        label1.setBounds(560,180,400,35);
	        l3.add(label1);
	        
	        textField = new JPasswordField();
	        textField.setBackground(new Color(65,125,128));
	        textField.setForeground(Color.WHITE);
	        textField.setBounds(460,230,320,25);
	        textField.setFont(new Font("Raleway", Font.BOLD,22));
	        l3.add(textField);

	        b1 = new JButton("Next");
	        b1.setBounds(700,362,150,35);
	        b1.setBackground(new Color(65,125,128));
	        b1.setForeground(Color.WHITE);
	        b1.addActionListener(this);
	        l3.add(b1);
	        
	        b2 = new JButton("PIN GENERATION");
	        b2.setBounds(700,406,150,35);
	        b2.setBackground(new Color(65,125,128));
	        b2.setForeground(Color.WHITE);
	        b2.addActionListener(this);
	        l3.add(b2);
	        
	        b3 = new JButton("EXIT");
	        b3.setForeground(Color.WHITE);
	        b3.setBackground(new Color(65,125,128));
	        b3.setBounds(410,406,150,35);
	        b3.addActionListener(this);
	        l3.add(b3);
	        	        	        	         
		setLayout(null);
        setSize(1550,1080);
        setLocation(0,0);
		//setUndecorated(true);
        setVisible(true);
        //t =new Timer(20000,this);// 20 minisecond
        //t.start();

	}
	  public void actionPerformed(ActionEvent e) {
		  
	        try {
	        	/*if(e.getSource()==t)
	         	{
	         			//t.stop();
	     int reply=JOptionPane.showConfirmDialog(null,"Do you want continue?","ATM Time Warning",JOptionPane.YES_NO_OPTION);

	    	             if (reply == JOptionPane.YES_OPTION)
	    	   			{
	    	   				t.start();
	    	   		    }
	    	   		  else if (reply == JOptionPane.NO_OPTION)
	    	   		    {
	             	       setVisible(false);
	    	   		    	//t.stop();

	    		        }
	         	}*/

	        	if(e.getSource()==b1)
				{   
					DatabaseConnection c = new DatabaseConnection();
	                pin = textField.getText();
	                System.out.println(pin);
	                String q = "select * from login where pin = '"+pin+"'";
	                ResultSet resultSet = c.st.executeQuery(q);
	                if (resultSet.next()){
	                    setVisible(false);
	                    new Main_Class(pin);
	                }else {
	                    JOptionPane.showMessageDialog(null,"Incorrect PIN");
	                    textField.setText("");
	                }
					
				}
	        	else if(e.getSource()==b2)
	        	{
	        	     JOptionPane.showMessageDialog(null, "PIN Generation request taken successfully \n Your pin is  "+first+" \nPlease change the pin");
	        	     DatabaseConnection c1 = new DatabaseConnection();
	                    String q1 = "insert into login (pin) values('"+first+"')";
	                    c1.st.executeUpdate(q1);
	        	     setVisible(false);
	                 new Main_Class(pin);    		
	        	}
	        	else {
	                setVisible(false);

	        	}
	        }        	
				
			 catch (Exception e2) {
					e2.printStackTrace();
			}
			} 
	           
	public static void main(String[] args) {
		
		new Login1();

	}

}
