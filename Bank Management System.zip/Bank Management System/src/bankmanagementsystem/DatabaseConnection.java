package bankmanagementsystem;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.Statement;

public class DatabaseConnection {
	Connection con;
	Statement st;

	public DatabaseConnection(){
		try {
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1522:ORCL","scott","2001");
			st=con.createStatement();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	

}
